TRIBALHERB WEBSITE
Open index.html to run the project.
Files include home page, plant search, farmer registration, cart/localStorage and Perenual API integration.
Replace YOUR_NEW_PERENUAL_API_KEY in script.js and plants.js with a new key. Do not publish a real API key to a public GitHub repository.
Demo photos use LoremFlickr placeholders; replace them with properly sourced/licensed photos for production and verify photo provenance before labeling them as specific tribal/community/location photos.
